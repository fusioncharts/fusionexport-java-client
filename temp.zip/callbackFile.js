document.body.style.background = 'pink';
